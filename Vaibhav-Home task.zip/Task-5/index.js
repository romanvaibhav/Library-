let myLeads = [];
let viewList=[];
// let Trulist=[];
const bookName=document.getElementById("bookinput");
const bookAuthor=document.getElementById("authorinput");
const bookCategory=document.getElementById("bookCategory");
const displayBook= document.getElementById("textContent");
const notext=document.getElementById("notext");
// const sessionStorage=JSON.parse(sessionStorage.getItem("Trulist"));
const leadsFromLocalStorage = JSON.parse(localStorage.getItem("myLeads"));
const filterBook=document.getElementById("filterBook");

if (leadsFromLocalStorage) {
    myLeads = leadsFromLocalStorage;
    render(myLeads);
}
function Add(){
    checkDuplicate();

    if (bookName.value.trim() === "") {
        alert("Please enter the book Name and Author Name!");
    }
    else if(bookAuthor.value.trim === ""){
        alert("Please enter the book Name and Author Name!");
    }
    else if(bookName.value.length > 0 && bookAuthor.value.length > 0 ){
        const Bookinfo={
            id:Date.now(),
            name:bookName.value,
            author:bookAuthor.value,
            category:bookCategory.value,
            read:false,
        }
        myLeads.push(Bookinfo);
        bookName.value = "";
        bookAuthor.value="";
        localStorage.setItem("myLeads", JSON.stringify(myLeads));
        render(myLeads);
        console.log(myLeads);
    }
    else{
        alert("Enter Valid Values");
    }
}
function render(leads){
    if(leads.length===0){
        notext.textContent="No books in your library";
        render(leads);
        
    }
    else if(leads.length>5){
        alert("50 books are already present in the library!")
    }
    else{
        notext.textContent="";
        let listItems = ""
        for(let i=0;i<leads.length;i++){
            listItems+=`
                <li class="textli">
                    <button onclick="handleButtonClick(${leads[i].id})" class="listBtn ${ leads[i].read ? "iconTick" : ""}  id="tick">  ${leads[i].read ? '\u2713' : " "}</button>
                <div>
                    <p class="dateStyle"> Book Name: ${leads[i].name}</p>
                    <p class="dateStyle"> Author: ${leads[i].author}</p>
                </div>    
                   <div class="delStyle"><button onclick="delButtonClick(${leads[i].id})" class="delBtn">\u00d7</button></div>
                </li>  
                `;
        }
        displayBook.innerHTML=listItems
    }
}
function delButtonClick(indez) {
    console.log(myLeads);
    myLeads = myLeads.filter((val) => val.id != indez)
    console.log(myLeads);
    localStorage.setItem("myLeads", JSON.stringify(myLeads));
    render(myLeads)
}
function handleButtonClick(info){
    console.log(info);
    for(let i=0;i<myLeads.length;i++){
        if(myLeads[i].id===info){
            if(myLeads[i].read==true){
                myLeads[i].read=false
            }
            else{
                myLeads[i].read=true;
            }
            
        }
    }
    localStorage.setItem("myLeads", JSON.stringify(myLeads));
    render(myLeads);
  
}

// function View(){
//     const viewCategory=bookCategory.value;
//     for(let i=0;i<myLeads.length;i++){
//         if(myLeads[i].category == viewCategory && myLeads[i].read == true){
//             render(myLeads)
//             Trulist[i]=myLeads[i];
//         }
//     }
//     render(Trulist);

// }
function checkDuplicate(){
    for(let i=0;i<myLeads.length;i++){
        if(myLeads[i].name === bookName.value ) {
            alert("Duplicate entries are not allowed");
            bookName.value="";
            bookAuthor.value="";
            // bookCategory.value="";
        }
        else if(myLeads[i].author === bookAuthor.value){
            alert("Duplicate entries are not allowed");
            bookName.value="";
            bookAuthor.value="";
            // bookCategory.value="";
        }
    }

}

// function Filter(){
//     render(myLeads);
// }